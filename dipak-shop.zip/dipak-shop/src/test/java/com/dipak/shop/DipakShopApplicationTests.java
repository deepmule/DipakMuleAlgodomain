package com.dipak.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DipakShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
