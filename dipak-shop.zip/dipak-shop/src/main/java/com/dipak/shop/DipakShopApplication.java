package com.dipak.shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DipakShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(DipakShopApplication.class, args);
	}

}
